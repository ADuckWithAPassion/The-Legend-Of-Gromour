<?xml version="1.0" encoding="UTF-8"?>
<tileset name="BFT - Legend Of Pocket Monsters Tileset" tilewidth="16" tileheight="16" tilecount="1484" columns="28">
 <image source="../../../Downloads/BFT - Legend Of Pocket Monsters Tileset.png" width="448" height="848"/>
</tileset>
