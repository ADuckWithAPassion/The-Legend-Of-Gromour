<?xml version="1.0" encoding="UTF-8"?>
<tileset name="BFT - Legend Of Pocket Monsters Tileset2" tilewidth="32" tileheight="32" tilecount="364" columns="14">
 <image source="../../../Downloads/BFT - Legend Of Pocket Monsters Tileset.png" width="448" height="848"/>
</tileset>
